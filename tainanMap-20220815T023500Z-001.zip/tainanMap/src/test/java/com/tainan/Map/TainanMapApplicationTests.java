package com.tainan.Map;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TainanMapApplicationTests {

	@Test
	void contextLoads() {
	}

}

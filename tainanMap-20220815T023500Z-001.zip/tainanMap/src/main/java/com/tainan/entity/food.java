package com.tainan.entity;

public class food implements java.io.Serializable{
	//private String 緯度;
	//private String 經度;
	private String 區域;
	private String 緯度;
	private String 經度;
	private String 地址;
	private String 店名;
	private String 評價分數;
	private String 評論人數;
	private String 照片;
	private String 更新時間;
	public String get緯度() {
		return 緯度;
	}
	public void set緯度(String 緯度) {
		this.緯度 = 緯度;
	}
	public String get經度() {
		return 經度;
	}
	public void set經度(String 經度) {
		this.經度 = 經度;
	}
	public String get地址() {
		return 地址;
	}
	public void set地址(String 地址) {
		this.地址 = 地址;
	}
	public String get店名() {
		return 店名;
	}
	public void set店名(String 店名) {
		this.店名 = 店名;
	}
	public String get評價分數() {
		return 評價分數;
	}
	public void set評價分數(String 評價分數) {
		this.評價分數 = 評價分數;
	}

	public String get評論人數() {
		return 評論人數;
	}
	public void set評論人數(String 評論人數) {
		this.評論人數 = 評論人數;
	}
	public String get照片() {
		return 照片;
	}
	public void set照片(String 照片) {
		this.照片 = 照片;
	}
	public String get更新時間() {
		return 更新時間;
	}
	public void set更新時間(String 更新時間) {
		this.更新時間 = 更新時間;
	}
	public String get區域() {
		return 區域;
	}
	public void set區域(String 區域) {
		this.區域 = 區域;
	}
	
	
	
}
